
import pandas as pd
from src.preprocess import preprocess_data

def test_no_nulls():
    preprocess_data("data/student_data.csv", "data/cleaned_student_data.csv")
    df = pd.read_csv("data/cleaned_student_data.csv")
    assert df.isnull().sum().sum() == 0
