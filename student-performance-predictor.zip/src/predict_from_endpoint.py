
from google.cloud import aiplatform

def predict_instance(endpoint_id, project, location, instance_dict):
    aiplatform.init(project=project, location=location)
    endpoint = aiplatform.Endpoint(endpoint_name=endpoint_id)
    prediction = endpoint.predict([instance_dict])
    print(f"Prediction: {prediction.predictions}")

if __name__ == "__main__":
    sample = {
        "study_hours": 6,
        "attendance": 92,
        "previous_score": 80
    }
    predict_instance("your-endpoint-id", "your-project-id", "us-central1", sample)
