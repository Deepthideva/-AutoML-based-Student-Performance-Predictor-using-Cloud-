
import pandas as pd

def preprocess_data(file_path: str, output_path: str):
    df = pd.read_csv(file_path)
    df.fillna(df.mean(numeric_only=True), inplace=True)
    df.to_csv(output_path, index=False)

if __name__ == "__main__":
    preprocess_data("data/student_data.csv", "data/cleaned_student_data.csv")
