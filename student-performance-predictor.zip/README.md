# Student Performance Predictor

A project using AutoML on GCP to predict exam scores.
